var searchData=
[
  ['localreuniaonuloouvazioexception_0',['LocalReuniaoNuloOuVazioException',['../class_excecoes_1_1_reuniao_exception_1_1_local_reuniao_nulo_ou_vazio_exception.html#a778aeee3550e204a0086348c3a582de2',1,'Excecoes::ReuniaoException::LocalReuniaoNuloOuVazioException']]]
];
