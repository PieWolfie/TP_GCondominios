var searchData=
[
  ['system_0',['System',['../_excecoes_8cs.html#a81a223a02c34d82b47199f08308847f2',1,'Excecoes.cs']]]
];
