var searchData=
[
  ['horareuniaoinvalidaexception_0',['HoraReuniaoInvalidaException',['../class_excecoes_1_1_reuniao_exception_1_1_hora_reuniao_invalida_exception.html',1,'Excecoes::ReuniaoException']]]
];
