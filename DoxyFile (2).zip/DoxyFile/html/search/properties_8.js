var searchData=
[
  ['presencasreunioes_0',['PresencasReunioes',['../class_objetos_negocio_1_1_proprietario.html#a190fc489825b2ef35edf2cdc4d89e700',1,'ObjetosNegocio::Proprietario']]],
  ['proprietarios_1',['proprietarios',['../interface_interfaces_1_1_i_imovel.html#a4f4a64afddf94ee394c1a18513796ff2',1,'Interfaces.IImovel.Proprietarios'],['../interface_interfaces_1_1_i_condominio.html#a601393f568cf892ebd7f2600d50b689f',1,'Interfaces.ICondominio.Proprietarios'],['../class_objetos_negocio_1_1_condominio.html#a837565a56ae379439974a43fdb7a360a',1,'ObjetosNegocio.Condominio.Proprietarios'],['../class_objetos_negocio_1_1_imovel.html#a7559fd24680ba72666f9e3d529a6c5d9',1,'ObjetosNegocio.Imovel.Proprietarios']]]
];
