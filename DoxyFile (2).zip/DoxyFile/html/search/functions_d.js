var searchData=
[
  ['tipodespesanuloouvazioexception_0',['TipoDespesaNuloOuVazioException',['../class_excecoes_1_1_despesa_exception_1_1_tipo_despesa_nulo_ou_vazio_exception.html#a8c43722bb024f7d7be5ffe5854615825',1,'Excecoes::DespesaException::TipoDespesaNuloOuVazioException']]],
  ['tipodocumentonuloouvazioexception_1',['TipoDocumentoNuloOuVazioException',['../class_excecoes_1_1_documento_exception_1_1_tipo_documento_nulo_ou_vazio_exception.html#a755a3376bb4b01b051b272c93d07304f',1,'Excecoes::DocumentoException::TipoDocumentoNuloOuVazioException']]]
];
