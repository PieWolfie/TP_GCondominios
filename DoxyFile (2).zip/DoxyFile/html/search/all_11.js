var searchData=
[
  ['valor_0',['valor',['../interface_interfaces_1_1_i_despesa.html#aa5b7f40dbec2b637bf6d64147b44d07e',1,'Interfaces.IDespesa.Valor'],['../class_objetos_negocio_1_1_despesa.html#a1c4179af50f1cdee32019b07d0dcc7b0',1,'ObjetosNegocio.Despesa.Valor']]],
  ['valordespesainvalidoexception_1',['valordespesainvalidoexception',['../class_excecoes_1_1_despesa_exception_1_1_valor_despesa_invalido_exception.html',1,'Excecoes.DespesaException.ValorDespesaInvalidoException'],['../class_excecoes_1_1_despesa_exception_1_1_valor_despesa_invalido_exception.html#ab5e3c8fdaf4ac7d81ee90de2fb71cb2d',1,'Excecoes.DespesaException.ValorDespesaInvalidoException.ValorDespesaInvalidoException()']]],
  ['visualizarhistorico_2',['VisualizarHistorico',['../class_objetos_negocio_1_1_proprietario.html#aa7b3795199735c239e444ce97a2172b9',1,'ObjetosNegocio::Proprietario']]]
];
