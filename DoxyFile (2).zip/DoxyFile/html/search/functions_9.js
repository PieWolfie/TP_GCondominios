var searchData=
[
  ['obtercondominiopornome_0',['ObterCondominioPorNome',['../class_dados_1_1_condominios.html#a5de40fac9d95f37ad2a5a0be7951a01e',1,'Dados::Condominios']]],
  ['obtercondominios_1',['ObterCondominios',['../class_dados_1_1_condominios.html#acf50c656e5e62f794771fbd8bd2c7eae',1,'Dados::Condominios']]],
  ['obterdespesaportipovaloredata_2',['ObterDespesaPorTipoValorEData',['../class_dados_1_1_despesas.html#a1b69235e0803053982cdb49a7652c7df',1,'Dados::Despesas']]],
  ['obterdespesas_3',['ObterDespesas',['../class_dados_1_1_despesas.html#a691e5b3767ae1d7ca518ae708ddfeb52',1,'Dados::Despesas']]],
  ['obterdocumentoportipoenome_4',['ObterDocumentoPorTipoENome',['../class_dados_1_1_documentos.html#aee9dbd05b5cab867a744e999dfeee136',1,'Dados::Documentos']]],
  ['obterdocumentos_5',['ObterDocumentos',['../class_dados_1_1_documentos.html#ac584f2add07b2f5872c06c07b305e376',1,'Dados::Documentos']]],
  ['obterimoveis_6',['ObterImoveis',['../class_dados_1_1_imoveis.html#a797f9e3e8cc396e5307fc0bf4212d7f4',1,'Dados::Imoveis']]],
  ['obterimovelporid_7',['ObterImovelPorId',['../class_dados_1_1_imoveis.html#aed7d908e4215119ae7af7be814ec6125',1,'Dados::Imoveis']]],
  ['obterproprietariopornif_8',['ObterProprietarioPorNif',['../class_dados_1_1_proprietarios.html#a41e36a395c4ecc94cce6bf755181b304',1,'Dados::Proprietarios']]],
  ['obterproprietarios_9',['ObterProprietarios',['../class_dados_1_1_proprietarios.html#afe75d8778830c6f8fdc58eb06a684e66',1,'Dados::Proprietarios']]],
  ['obterreuniao_10',['ObterReuniao',['../class_dados_1_1_reunioes.html#aff114de80c8f48c65d745c0eaba00f85',1,'Dados::Reunioes']]],
  ['obterreunioes_11',['ObterReunioes',['../class_dados_1_1_reunioes.html#a9277ad5f59485f637f6613def3c2e592',1,'Dados::Reunioes']]],
  ['obtersaldo_12',['ObterSaldo',['../class_objetos_negocio_1_1_imovel.html#acac4fdb9de60d4fede8bd8e589839437',1,'ObjetosNegocio::Imovel']]],
  ['obtervalortotal_13',['ObterValorTotal',['../class_objetos_negocio_1_1_despesa.html#ae0fa7c2b50ad1ad40dcd7d949b337978',1,'ObjetosNegocio::Despesa']]]
];
