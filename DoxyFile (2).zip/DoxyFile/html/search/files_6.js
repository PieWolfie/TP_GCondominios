var searchData=
[
  ['objetosnegocio_2eassemblyinfo_2ecs_0',['ObjetosNegocio.AssemblyInfo.cs',['../_objetos_negocio_8_assembly_info_8cs.html',1,'']]],
  ['objetosnegocio_2eglobalusings_2eg_2ecs_1',['ObjetosNegocio.GlobalUsings.g.cs',['../_objetos_negocio_8_global_usings_8g_8cs.html',1,'']]]
];
