var searchData=
[
  ['nifproprietarionuloouvazioexception_0',['NifProprietarioNuloOuVazioException',['../class_excecoes_1_1_proprietario_exception_1_1_nif_proprietario_nulo_ou_vazio_exception.html#ad431f283d2718843b0d90986624e4959',1,'Excecoes::ProprietarioException::NifProprietarioNuloOuVazioException']]],
  ['nomecondominionuloouvazioexception_1',['NomeCondominioNuloOuVazioException',['../class_excecoes_1_1_condominio_exception_1_1_nome_condominio_nulo_ou_vazio_exception.html#ad88a8433427a7d132e8826584b680f86',1,'Excecoes::CondominioException::NomeCondominioNuloOuVazioException']]],
  ['nomedocumentonuloouvazioexception_2',['NomeDocumentoNuloOuVazioException',['../class_excecoes_1_1_documento_exception_1_1_nome_documento_nulo_ou_vazio_exception.html#a7a38bfd3fd011b08911422a614917d85',1,'Excecoes::DocumentoException::NomeDocumentoNuloOuVazioException']]],
  ['nomeproprietarionuloouvazioexception_3',['NomeProprietarioNuloOuVazioException',['../class_excecoes_1_1_proprietario_exception_1_1_nome_proprietario_nulo_ou_vazio_exception.html#aa163043fe906719f32b4a15bc6229df6',1,'Excecoes::ProprietarioException::NomeProprietarioNuloOuVazioException']]]
];
