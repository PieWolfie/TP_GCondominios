var searchData=
[
  ['valor_0',['valor',['../interface_interfaces_1_1_i_despesa.html#aa5b7f40dbec2b637bf6d64147b44d07e',1,'Interfaces.IDespesa.Valor'],['../class_objetos_negocio_1_1_despesa.html#a1c4179af50f1cdee32019b07d0dcc7b0',1,'ObjetosNegocio.Despesa.Valor']]]
];
