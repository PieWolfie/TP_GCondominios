var searchData=
[
  ['valordespesainvalidoexception_0',['ValorDespesaInvalidoException',['../class_excecoes_1_1_despesa_exception_1_1_valor_despesa_invalido_exception.html',1,'Excecoes::DespesaException']]]
];
