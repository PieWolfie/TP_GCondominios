var searchData=
[
  ['localreuniaonuloouvazioexception_0',['LocalReuniaoNuloOuVazioException',['../class_excecoes_1_1_reuniao_exception_1_1_local_reuniao_nulo_ou_vazio_exception.html',1,'Excecoes::ReuniaoException']]]
];
