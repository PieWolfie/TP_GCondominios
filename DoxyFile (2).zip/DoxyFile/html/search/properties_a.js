var searchData=
[
  ['reunioes_0',['reunioes',['../interface_interfaces_1_1_i_condominio.html#a1832b2b71cce529d2f2d7fc1c83f793f',1,'Interfaces.ICondominio.Reunioes'],['../class_objetos_negocio_1_1_condominio.html#ac9771bdff7e977cd04c119dc098d2fa6',1,'ObjetosNegocio.Condominio.Reunioes']]]
];
