var searchData=
[
  ['enderecocondominionuloouvazioexception_0',['EnderecoCondominioNuloOuVazioException',['../class_excecoes_1_1_condominio_exception_1_1_endereco_condominio_nulo_ou_vazio_exception.html',1,'Excecoes::CondominioException']]],
  ['enderecoimovelnuloouvazioexception_1',['EnderecoImovelNuloOuVazioException',['../class_excecoes_1_1_imovel_exception_1_1_endereco_imovel_nulo_ou_vazio_exception.html',1,'Excecoes::ImovelException']]]
];
