var searchData=
[
  ['valordespesainvalidoexception_0',['ValorDespesaInvalidoException',['../class_excecoes_1_1_despesa_exception_1_1_valor_despesa_invalido_exception.html#ab5e3c8fdaf4ac7d81ee90de2fb71cb2d',1,'Excecoes::DespesaException::ValorDespesaInvalidoException']]],
  ['visualizarhistorico_1',['VisualizarHistorico',['../class_objetos_negocio_1_1_proprietario.html#aa7b3795199735c239e444ce97a2172b9',1,'ObjetosNegocio::Proprietario']]]
];
