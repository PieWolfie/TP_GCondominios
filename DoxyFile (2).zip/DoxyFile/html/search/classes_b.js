var searchData=
[
  ['tipodespesanuloouvazioexception_0',['TipoDespesaNuloOuVazioException',['../class_excecoes_1_1_despesa_exception_1_1_tipo_despesa_nulo_ou_vazio_exception.html',1,'Excecoes::DespesaException']]],
  ['tipodocumentonuloouvazioexception_1',['TipoDocumentoNuloOuVazioException',['../class_excecoes_1_1_documento_exception_1_1_tipo_documento_nulo_ou_vazio_exception.html',1,'Excecoes::DocumentoException']]]
];
