var searchData=
[
  ['tipo_0',['tipo',['../interface_interfaces_1_1_i_despesa.html#ab9c55d4e63a2e9bd2fd30f209413d2ec',1,'Interfaces.IDespesa.Tipo'],['../interface_interfaces_1_1_i_documento.html#a8261e277bcf15c26c1dd9d177237e252',1,'Interfaces.IDocumento.Tipo'],['../class_objetos_negocio_1_1_despesa.html#a260708ff1fcd7c48ef576bc86caf1ab8',1,'ObjetosNegocio.Despesa.Tipo'],['../class_objetos_negocio_1_1_documento.html#a8405540bd4088ef6e6fb2f350ee52706',1,'ObjetosNegocio.Documento.Tipo']]]
];
