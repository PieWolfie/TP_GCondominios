var searchData=
[
  ['local_0',['local',['../interface_interfaces_1_1_i_reuniao.html#a04e37cfb2b7db245ddb30cc6eb300746',1,'Interfaces.IReuniao.Local'],['../class_objetos_negocio_1_1_reuniao.html#a482bde275d7e59b9df91adb286480107',1,'ObjetosNegocio.Reuniao.Local']]]
];
