var searchData=
[
  ['nifproprietarionuloouvazioexception_0',['NifProprietarioNuloOuVazioException',['../class_excecoes_1_1_proprietario_exception_1_1_nif_proprietario_nulo_ou_vazio_exception.html',1,'Excecoes::ProprietarioException']]],
  ['nomecondominionuloouvazioexception_1',['NomeCondominioNuloOuVazioException',['../class_excecoes_1_1_condominio_exception_1_1_nome_condominio_nulo_ou_vazio_exception.html',1,'Excecoes::CondominioException']]],
  ['nomedocumentonuloouvazioexception_2',['NomeDocumentoNuloOuVazioException',['../class_excecoes_1_1_documento_exception_1_1_nome_documento_nulo_ou_vazio_exception.html',1,'Excecoes::DocumentoException']]],
  ['nomeproprietarionuloouvazioexception_3',['NomeProprietarioNuloOuVazioException',['../class_excecoes_1_1_proprietario_exception_1_1_nome_proprietario_nulo_ou_vazio_exception.html',1,'Excecoes::ProprietarioException']]]
];
